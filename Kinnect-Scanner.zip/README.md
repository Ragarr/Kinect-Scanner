# Kinnect-Scanner
Objetive: making a 3d scanner using kinnect depth sensor
